krediler = ["Hızlı krediler", "Maaşını Halkbank'tan alanlara özel", "Mutlu emekli ihtiyaç kredisi"]
print(krediler)
print(krediler[0])
print(krediler[1])
print(krediler[2])
print(len(krediler))
krediler[0] = "Çabuk krediler"
print(krediler)
print(krediler[3])