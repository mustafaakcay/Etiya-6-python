baslik = "Haberiniz Olsun"
vade = 12
faizOrani1 = 1.47
faizOrani2 = 1.44
faiZOrani = 1.47
print(baslik)
print(type(baslik))
print(type(vade))
print(type(faiZOrani))
mesaj = "Hosgeldin"
musteriAdi = "Mustafa"
musteriSoyadi = "Akcay"
sonucMesaj = mesaj+" "+musteriAdi+" "+musteriSoyadi+"!"
print(sonucMesaj)
sayi1 = 10
sayi2 = 20
print(sayi1+sayi2)
print(sonucMesaj)