def kredileriListele(): 
  krediler = ["Hızlı krediler", "Maaşını Halkbank'tan alanlara özel", "Mutlu emekli ihtiyaç kredisi"]
  for kredi in krediler: 
    print("<option>"+kredi+"<option>")
    
    
kredileriListele()